# A Typography Guide: Serif Families

A Pen created on CodePen.

Original URL: [https://codepen.io/justinav/pen/yLOpdK](https://codepen.io/justinav/pen/yLOpdK).

