# A Typography Style Guide: Sans Serif

A Pen created on CodePen.

Original URL: [https://codepen.io/justinav/pen/poydNz](https://codepen.io/justinav/pen/poydNz).

