class StaticPagesController < ApplicationController
  def intro
  end

  def safety
  end

  def rules
  end

  def privacy
  end
end

