
Forem.layout = "application"
Forem.per_page = 15

# -------------------------------------------------

Forem.user_class = "User"
Forem.sign_in_path = "/users/sign_in"
Forem.user_profile_links = true

# -------------------------------------------------

Forem.email_from_address = "#{I18n.t(:noreply)}@brgen.no"

