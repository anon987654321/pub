
Paperclip::PaperclipOptimizer.default_options = {
  skip_missing_workers: true,
  advpng: false,
  gifsicle: false,
  jhead: false,
  jpegoptim: false,
  jpegrecompress: false,
  jpegtran: false,
  optipng: false,
  pngcrush: false,
  pngout: false,
  pngquant: false,
  svgo: false
}

