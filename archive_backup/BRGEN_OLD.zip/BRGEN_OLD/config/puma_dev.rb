#!/usr/bin/env puma

environment "development"

