
# sites = Site.create([
#   {
#    name: "Brgen",
#    domain: "brgen.no",
#    country: "Norway",
#    city: "Bergen",
#    language: "nb.yml",
#    favicon: "favicon_brgen.ico",
#    block_foreign_ips_from_posting: true,
#    database_sharing: true,
#    facebook_username: "brgen",
#    facebook_password: "",
#    google_username: "brgen",
#    google_password: "",
#    analytics: "_analytics_brgen.html.erb"
#   }
# ])
#
# sites = Site.create([
#   {
#    name: "Oshlo",
#    domain: "oshlo.no",
#    country: "Norway",
#    city: "Oslo",
#    language: "nb.yml",
#    favicon: "favicon_oshlo.ico",
#    block_foreign_ips_from_posting: true,
#    database_sharing: true,
#    facebook_username: "oshlo",
#    facebook_password: "",
#    google_username: "oshlo",
#    google_password: "",
#    analytics: "_analytics_oshlo.html.erb"
#   }
# ])
#
# sites = Site.create([
#   {
#    name: "Trndheim",
#    domain: "trndheim.no",
#    country: "Norway",
#    city: "Trondheim",
#    language: "nb.yml",
#    favicon: "favicon_trndheim.ico",
#    block_foreign_ips_from_posting: true,
#    database_sharing: true,
#    facebook_username: "trndheim",
#    facebook_password: "",
#    google_username: "trndheim",
#    google_password: "",
#    analytics: "_analytics_trndheim.html.erb"
#   }
# ])
#
# sites = Site.create([
#   {
#    name: "Stvanger",
#    domain: "stvanger.no",
#    country: "Norway",
#    city: "Stavanger",
#    language: "nb.yml",
#    favicon: "favicon_stvanger.ico",
#    block_foreign_ips_from_posting: true,
#    database_sharing: true,
#    facebook_username: "stvanger",
#    facebook_password: "",
#    google_username: "stvanger",
#    google_password: "",
#    analytics: "_analytics_stvanger.html.erb"
#   }
# ])
#
# sites = Site.create([
#   {
#    name: "Krsand",
#    domain: "krsand.no",
#    country: "Norway",
#    city: "Kristiansand",
#    language: "nb.yml",
#    favicon: "favicon_krsand.ico",
#    block_foreign_ips_from_posting: true,
#    database_sharing: true,
#    facebook_username: "krsand",
#    facebook_password: "",
#    google_username: "krsand",
#    google_password: "",
#    analytics: "_analytics_krsand.html.erb"
#   }
# ])
#
# sites = Site.create([
#   {
#    name: "Frdrikstad",
#    domain: "frdrikstad.no",
#    country: "Norway",
#    city: "Fredrikstad",
#    language: "nb.yml",
#    favicon: "favicon_frdrikstad.ico",
#    block_foreign_ips_from_posting: true,
#    database_sharing: true,
#    facebook_username: "frdrikstad",
#    facebook_password: "",
#    google_username: "frdrikstad",
#    google_password: "",
#    analytics: "_analytics_frdrikstad.html.erb"
#   }
# ])
#
# sites = Site.create([
#   {
#    name: "Trmso",
#    domain: "trmso.no",
#    country: "Norway",
#    city: "Tromsø",
#    language: "nb.yml",
#    favicon: "favicon_trmso.ico",
#    block_foreign_ips_from_posting: true,
#    database_sharing: true,
#    facebook_username: "trmso",
#    facebook_password: "",
#    google_username: "trmso",
#    google_password: "",
#    analytics: "_analytics_trmso.html.erb"
#   }
# ])
#
# sites = Site.create([
#   {
#    name: "Drmmen",
#    domain: "drmmen.no",
#    country: "Norway",
#    city: "Drammen",
#    language: "nb.yml",
#    favicon: "favicon_drmmen.ico",
#    block_foreign_ips_from_posting: true,
#    database_sharing: true,
#    facebook_username: "drmmen",
#    facebook_password: "",
#    google_username: "drmmen",
#    google_password: "",
#    analytics: "_analytics_drmmen.html.erb"
#   }
# ])
#
# sites = Site.create([
#   {
#    name: "Aalesnd",
#    domain: "aalesnd.no",
#    country: "Norway",
#    city: "Ålesund",
#    language: "nb.yml",
#    favicon: "favicon_aalesnd.ico",
#    block_foreign_ips_from_posting: true,
#    database_sharing: true,
#    facebook_username: "aalesnd",
#    facebook_password: "",
#    google_username: "aalesnd",
#    google_password: "",
#    analytics: "_analytics_aalesnd.html.erb"
#   }
# ])
#
# sites = Site.create([
#   {
#    name: "Lngyearbyen",
#    domain: "lngyearbyen.no",
#    country: "Norway",
#    city: "Longyearbyen",
#    language: "nb.yml",
#    favicon: "favicon_lngyearbyen.ico",
#    block_foreign_ips_from_posting: true,
#    database_sharing: true,
#    facebook_username: "lngyearbyen",
#    facebook_password: "",
#    google_username: "lngyearbyen",
#    google_password: "",
#    analytics: "_analytics_lngyearbyen.html.erb"
#   }
# ])

