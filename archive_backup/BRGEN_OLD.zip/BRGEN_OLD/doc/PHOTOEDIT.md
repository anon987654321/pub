# Photoedit

    node photoedit/bin/convert.js -h

