module.exports = require('require-dir')('.');

