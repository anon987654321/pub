@home = "/home/www/brgen"
@apikey = "#{ @home }/.apikeys"
@spyder = "/usr/local/bin/spyder"
@effects_file = "#{ @home }/photoedit/effects.json"

# -------------------------------------------------

@variance = "30000"

