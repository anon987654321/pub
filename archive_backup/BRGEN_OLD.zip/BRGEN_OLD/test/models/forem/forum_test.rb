require 'test_helper'

class Forem::ForumTest < ActiveSupport::TestCase
  # def setup
  #   @forum = Forem::Forum.new({
  #     name: "Welcome to Forem!",
  #     description: "A Placeholder for Description",
  #     category_id: forem_categories(:general).id,
  #     forum_type_id: forum_types(:ad).id
  #   })
  # end
  #
  # def test_requires_a_forum_type
  #   @forum.forum_type_id = nil
  #   assert !@forum.valid?
  # end
end

