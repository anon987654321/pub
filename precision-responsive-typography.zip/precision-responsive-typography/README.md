# Precision responsive typography

A Pen created on CodePen.

Original URL: [https://codepen.io/MadeByMike/pen/YPJJYv](https://codepen.io/MadeByMike/pen/YPJJYv).

I've not seen this before so I think I've figured out something new and hopefully useful.

It appears that by using calc() and vw we can get responsive typography that scales perfectly between specific pixel values within a specific viewport range.

Check it out. (might be buggy in some browsers)

http://madebymike.com.au/writing/precise-control-responsive-typography/